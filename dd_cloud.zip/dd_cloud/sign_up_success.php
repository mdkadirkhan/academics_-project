<?php

$fname=$_POST["first_name"];
$lname=$_POST["last_name"];
$dob=$_POST["dob"];
$email=$_POST["email"];
$ps=md5($_POST["password"]);




//echo "welcome";
$conn=mysql_connect("localhost","dd_cloud","dd_cloud");

if($conn)
{
  echo "Database is connected";
}
else
{
  echo "Database is Not Connected";
  echo mysql_error();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>DeDuplication- Sign Up</title>

<!-- Google fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>

<!-- font awesome -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<!-- bootstrap -->
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />

<!-- animate.css -->
<link rel="stylesheet" href="assets/animate/animate.css" />
<link rel="stylesheet" href="assets/animate/set.css" />

<!-- gallery -->
<link rel="stylesheet" href="assets/gallery/blueimp-gallery.min.css">

<!-- favicon -->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">


<link rel="stylesheet" href="assets/style.css">

</head>

<body>
<div class="topbar animated fadeInLeftBig"></div>

<!-- Header Starts -->
<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-default navbar-fixed-top" role="navigation" id="top-nav">
          <div class="container">
            <div class="navbar-header">
              <!-- Logo Starts -->
              <a class="navbar-brand" href="home.html"><img src="images/logo3.png" alt="logo"></a>
              <!-- #Logo Ends -->


              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
                 <li class="active"><a href="index.php">Home</a></li>
                 <li ><a href="about.html">About</a></li>
                 <li ><a href="sign_up.php">Registration</a></li>
                 <li ><a href="login.php">Login</a></li>                
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>
<!-- #Header Starts -->




<div id="home">

<div id="about"  class="container spacer about">
<h2 class="text-center wowload fadeInUp">


<?php

mysql_select_db("dd_cloud");
$q_insert=mysql_query("insert into dd_cloud_registration
 values('','$fname','$lname','$dob','$email','$ps','Pending','')");


?>

<?php

if($q_insert)
{
echo "Registration is Successfully Completed<br>Your Account is Pending for Admin Approval.";
$q_get_last_userid=mysql_query("select * from dd_cloud_registration order by dd_cloud_registration_id desc");

$q_get_last_userid_result=mysql_affected_rows();

if ($q_get_last_userid_result>0) {
 
 $t=mysql_fetch_row($q_get_last_userid);

 $id=$t[0];

 if(mkdir("up/uploads/User_Cloud_Storage_$id"))
 {
 echo "Your Space allocated"; 

 }
 
}
}
else
{
echo "Error: Can't Perform Registration";
echo mysql_error();
}
?>

<br><br>

</div>

<!-- Cirlce Starts -->

  <div class="row">
  <div class="col-sm-6 wowload fadeInLeft">
    
    <p></p>
    

  </div>
  <div class="col-sm-6 wowload fadeInRight">
  
  <p></p>    
  </div>
  </div>
  </div>



<!-- Footer Starts -->
<div class="footer text-center spacer">
<p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-dribbble fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-linkedin fa-2x"></i></a> </p>
Copyright 2017 Team R.A.N.K . All rights reserved.
</div>
<!-- # Footer Ends -->

<!-- jquery -->
<script src="assets/jquery.js"></script>

<!-- wow script -->
<script src="assets/wow/wow.min.js"></script>


<!-- boostrap -->
<script src="assets/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="assets/mobile/touchSwipe.min.js"></script>
<script src="assets/respond/respond.js"></script>

<!-- gallery -->
<script src="assets/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="assets/script.js"></script>



<a href="#home" class="gototop "><i class="fa fa-angle-up  fa-3x"></i></a>
</body>
</html>