Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/drag-and-drop-file-upload-using-dropzone-php/

============ Introduction ============
This small project helps web developers to implement drag and drop files upload in PHP.

============ Installation ============
1. Create a database (codexworld) at phpMyAdmin.
2. Import the "files.sql" file into the database (codexworld).
3. Open the "upload.php" file and modify the $dbHost, $dbUsername, $dbPassword and $dbName variables value with your MySQL details.
4. Run the "index.html" file at the browser and test the functionalities.

============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/drag-and-drop-file-upload-using-dropzone-php/#respond. We will reply your query ASAP.