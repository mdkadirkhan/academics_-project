<?php
session_start();

if(!empty($_FILES)){
	$uid1=$_SESSION['dd_cloud_registration_id'];

include "../db_control.php";

	//database configuration
	/*$dbHost = 'localhost';
	$dbUsername = 'root';
	$dbPassword = '';
	$dbName = 'codexworld';*/
	//connect with the database
	//$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
	//if($mysqli->connect_errno){
	//	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	//}

$targetDir = "uploads/User_Cloud_Storage_$uid1/";
	$fileName = $_FILES['file']['name'];
	$targetFile = $targetDir.$fileName;
	if(move_uploaded_file($_FILES['file']['tmp_name'],$targetFile)){
		//insert file information into db table
		$filepath="uploads/User_Cloud_Storage_$uid1/";
		$filetype=$_FILES['file']['type'];
		$filesize=$_FILES['file']['size'];
		//$q_insert_data=mysql_query("INSERT INTO dd_cloud_files VALUES('','$uid1','$fileName','$filepath','$filetype','$filesize','$d')");
		$fd=fopen($filepath."/".$fileName,'r');
				if($fd)
				{
								while (!feof($fd)) {
									$data.=fgets($fd,2014);
													}
													$data1=md5($data);
												}


												//check duplication of cloud
$q_check_duplication=mysql_query("select * from dd_cloud_files where dd_cloud_files_userid='$uid1' and dd_cloud_files_filedata='$data1'");
													$q_check_duplication_result=mysql_affected_rows();
$_SESSION["dd_yes"]="";
													if($q_check_duplication_result>0)
													{
										
											$_SESSION["dd_yes"]="yes";
													}
													else
													{
													/*$q_update=mysql_query("update dd_cloud_files set dd_cloud_files_filedata='$data1' where dd_cloud_files_userid='$uid1' and ");	
													} */
												//check duplication of cloud
		$q_insert_data=mysql_query("insert into dd_cloud_files values('','$uid1','$fileName','$filepath','$filetype','$filesize','$data1')");
	}//end of else

		if(!$q_insert_data)
		{
			echo mysql_error();
		}
		else
		{
			/*if(file_exists($filepath/$fileName))
			{*/
		

			/*}*/
			
		}
			
	}
	
}
?>