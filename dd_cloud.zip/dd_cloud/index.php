<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>DeDuplication</title>
<!-- Google fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>

<!-- font awesome -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<!-- bootstrap -->
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />

<!-- animate.css -->
<link rel="stylesheet" href="assets/animate/animate.css" />
<link rel="stylesheet" href="assets/animate/set.css" />

<!-- gallery -->
<link rel="stylesheet" href="assets/gallery/blueimp-gallery.min.css">

<!-- favicon -->
<link rel="shortcut icon" href="images/logo_DD.ico" type="image/x-icon">
<link rel="icon" href="images/logo_DD.ico" type="image/x-icon">


<link rel="stylesheet" href="assets/style.css">

</head>

<body>
<div class="topbar animated fadeInLeftBig"></div>

<!-- Header Starts -->
<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-default navbar-fixed-top" role="navigation" id="top-nav">
          <div class="container">
            <div class="navbar-header">
              <!-- Logo Starts -->
              <a class="navbar-brand" href="index.php"><img src="images/logo3.png" alt="logo3"></a>
              <!-- #Logo Ends -->


              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
                 <li class="active"><a href="index.php">Home</a></li>
                 <li ><a href="about.html">About</a></li>
                 <li ><a href="sign_up.php">Registration</a></li>
                 <li ><a href="login.php">Login</a></li>  
                 <li ><a href="admin_login.php">Admin Login</a></li>               
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>
<!-- #Header Starts -->




<div id="home">
<!-- Slider Starts -->
<div id="myCarousel" class="carousel slide banner-slider animated flipInX" data-ride="carousel">     
      <div class="carousel-inner">
        <!-- Item 1 -->
        <div class="item active">
          <img src="images/lab.jpg" alt="banner">          
            <div class="carousel-caption">
              <div class="caption-wrapper">
                <div class="caption-info">
                <img src="images/logobig1.png" class="animated bounceInUp" alt="logo">
                  <h1 class="animated bounceInLeft">De-Duplication</h1>
                  <p class="animated bounceInRight">Lead by passionate and uber progressive team that lives and breathes design.</p>
                  <div class="animated fadeInUp"><a href="sign_up.html" class="btn btn-default"><i class="fa fa-flask"></i> Registration </a> <a href="login.php" class="btn btn-default"><i class="fa fa-paper-plane-o"></i> Login </a></div>
                  </div>
                </div>
            </div>
        </div>
        <!-- #Item 1 -->

        <!-- Item 1 -->
        <div class="item">
          <img src="images/back2.jpg" alt="banner">          
             <div class="carousel-caption">
              <div class="caption-wrapper">
                <div class="caption-info">
                <img src="images/logobig1.png" class="animated bounceInUp" alt="logo">
                  <h1 class="animated bounceInLeft">De-Duplication</h1>
                  <p class="animated bounceInRight">Lead by passionate and uber progressive team that lives and breathes design.</p>
                  <div class="animated fadeInUp"><a href="sign_up.html" class="btn btn-default"><i class="fa fa-flask"></i>  Registration </a> <a href="login.php" class="btn btn-default"><i class="fa fa-paper-plane-o"></i> Login </a></div>
                  </div>
                </div>
            </div>
        </div>
        <!-- #Item 1 -->

        <!-- Item 1 -->
        <div class="item">
          <img src="images/back3.jpg" alt="banner">          
             <div class="carousel-caption">

              <div class="caption-wrapper">
                <div class="caption-info">
                <img src="images/logobig1.png" class="animated bounceInUp" alt="logo">
                  <h1 class="animated bounceInLeft">De-Duplication</h1>
                  <p class="animated bounceInRight">Lead by passionate and uber progressive team that lives and breathes design.</p>
                  <div class="animated fadeInUp"><a href="sign_up.html" class="btn btn-default"><i class="fa fa-flask"></i>  Registration </a> <a href="login.php" class="btn btn-default"><i class="fa fa-paper-plane-o"></i> Login </a></div>
                  </div>
                </div>
            </div>
        </div>
        <!-- #Item 1 -->

        <!-- Item 1 -->
        <div class="item">
          <img src="images/back4.jpg" alt="banner">          
             <div class="carousel-caption">
              <div class="caption-wrapper">
                <div class="caption-info">
                <img src="images/logobig1.png" class="animated bounceInUp" alt="logo">
                  <h1 class="animated bounceInLeft">De-Duplication</h1>
                  <p class="animated bounceInRight">Lead by passionate and uber progressive team that lives and breathes design.</p>
                  <div class="animated fadeInUp"><a href="sign_up.html" class="btn btn-default"><i class="fa fa-flask"></i>  Registration </a> <a href="login.php" class="btn btn-default"><i class="fa fa-paper-plane-o"></i> Login </a></div>
                  </div>
                </div>
            </div>
        </div>
        <!-- #Item 1 -->
      </div>
      <a class="left carousel-control" href="#myCarousel" data-slide="prev"><span class="glyphicon-chevron-left"><i class="fa fa-angle-left"></i></span></a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next"><span class="glyphicon-chevron-right"><i class="fa fa-angle-right"></i></span></a>
    </div>
<!-- #Slider Ends -->
</div>


<!-- Cirlce Starts -->
<div id="about"  class="container spacer about">
<h2 class="text-center wowload fadeInUp">De-Duplication For Could Security</h2>  
  <div class="row">
  <div class="col-sm-6 wowload fadeInLeft">
    <h4><i class="fa fa-paint-brush"></i> Design</h4>
    <p>De-Duplication for sleek and sophisticated solutions for mobile, websites and software designs, lead by passionate and uber progressive team that lives and breathes design. De-Duplication for sleek and sophisticated solutions for mobile, websites and software designs.</p>
    

  </div>
  <div class="col-sm-6 wowload fadeInRight">
  <h4><i class="fa fa-code"></i> Frontend & Backend Development</h4>
  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>    
  </div>
  </div>

  </div>
</div>
<


<!-- Footer Starts -->
<div class="footer text-center spacer">
<p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-dribbble fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-linkedin fa-2x"></i></a> </p>
Copyright 2017 Team R.A.N.K . All rights reserved.
</div>
<!-- # Footer Ends -->

<!-- jquery -->
<script src="assets/jquery.js"></script>

<!-- wow script -->
<script src="assets/wow/wow.min.js"></script>


<!-- boostrap -->
<script src="assets/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="assets/mobile/touchSwipe.min.js"></script>
<script src="assets/respond/respond.js"></script>

<!-- gallery -->
<script src="assets/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="assets/script.js"></script>



<a href="#home" class="gototop "><i class="fa fa-angle-up  fa-3x"></i></a>
</body>
</html>