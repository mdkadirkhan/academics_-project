-- phpMyAdmin SQL Dump
-- version 4.0.4.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 27, 2017 at 11:52 AM
-- Server version: 5.6.13
-- PHP Version: 5.4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dd_cloud`
--
CREATE DATABASE IF NOT EXISTS `dd_cloud` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dd_cloud`;

-- --------------------------------------------------------

--
-- Table structure for table `dd_cloud_admin`
--

CREATE TABLE IF NOT EXISTS `dd_cloud_admin` (
  `dd_cloud_admin_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dd_cloud_admin_uname` varchar(30) NOT NULL,
  `dd_cloud_admin_pass` varchar(100) NOT NULL,
  PRIMARY KEY (`dd_cloud_admin_id`),
  UNIQUE KEY `dd_cloud_admin_id` (`dd_cloud_admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `dd_cloud_admin`
--

INSERT INTO `dd_cloud_admin` (`dd_cloud_admin_id`, `dd_cloud_admin_uname`, `dd_cloud_admin_pass`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'admin1', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `dd_cloud_registration`
--

CREATE TABLE IF NOT EXISTS `dd_cloud_registration` (
  `dd_cloud_registration_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dd_cloud_registration_fname` varchar(20) NOT NULL,
  `dd_cloud_registration_lname` varchar(20) NOT NULL,
  `dd_cloud_registration_dob` varchar(10) NOT NULL,
  `dd_cloud_registration_email` varchar(50) NOT NULL,
  `dd_cloud_registration_ps` varchar(30) NOT NULL,
  `dd_cloud_status` varchar(15) NOT NULL,
  `dd_cloud_registration_tt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dd_cloud_registration_id`),
  UNIQUE KEY `dd_cloud_registration_id` (`dd_cloud_registration_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `dd_cloud_registration`
--

INSERT INTO `dd_cloud_registration` (`dd_cloud_registration_id`, `dd_cloud_registration_fname`, `dd_cloud_registration_lname`, `dd_cloud_registration_dob`, `dd_cloud_registration_email`, `dd_cloud_registration_ps`, `dd_cloud_status`, `dd_cloud_registration_tt`) VALUES
(1, 'Abdul', 'Khan', '06/06/1998', 'mdkadirkhan535@gmail.com', '123456', '', '0000-00-00 00:00:00'),
(2, 'Kadir', 'Khan', '2017-02-15', 'info@gmail.com', '45664', '', '0000-00-00 00:00:00'),
(3, 'Kadir', 'Khan', '2017-02-15', 'info@gmail.com', '45664', '', '0000-00-00 00:00:00'),
(4, 'ahjag', 'jahjoiagio', '2017-02-25', 'jfaiohioh@yahoo.com', 'e0e41a561e4471dc9c3daf6ceb5ebb', '', '0000-00-00 00:00:00'),
(5, 'Rushabh', 'Panjwani', '2016-09-15', 'rushabhpanjwani@gmail.com', '05432010dfad5f3491d60a2cb4f734', 'Approved', '2017-02-25 08:42:33'),
(6, '', '', '', '', 'd41d8cd98f00b204e9800998ecf842', 'Approved', '2017-02-25 08:47:15'),
(8, '', '', '', '', 'd41d8cd98f00b204e9800998ecf842', 'Pending', '0000-00-00 00:00:00'),
(9, 'Sabir', 'Khan', '2000-01-20', 'sabirkhan123@gmail.com', '3fe8119b685d985cb5d5fa43e39032', 'Approved', '2017-02-26 14:47:57'),
(10, 'bhushan', 'thakare', '2017-02-08', 'bt@yahoo.com', '7e6057066eea303d2ca774d1b9c349', 'Pending', '2017-02-25 08:42:13'),
(11, 'Abdul', 'Khan', '2017-02-18', 'abdulkhan5355@gmail.com', '83c7c85afdac6c50af9c84331558fa', 'Pending', '2017-02-25 08:42:18'),
(12, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(13, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(14, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(15, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(16, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(17, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(18, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(19, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(20, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(21, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(22, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(23, 'user1', 'surname1', '2017-01-11', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f', 'Pending', '0000-00-00 00:00:00'),
(24, 'ru', 'pa', '2017-02-18', 'rupa123@gmail.com', '25f9e794323b453885f5181f1b624d', 'Pending', '0000-00-00 00:00:00'),
(25, 'ru', 'pa', '2017-02-18', 'rupa123@gmail.com', '25f9e794323b453885f5181f1b624d', 'Pending', '0000-00-00 00:00:00'),
(26, 'ru', 'pa', '2017-02-18', 'rupa123@gmail.com', '25f9e794323b453885f5181f1b624d', 'Pending', '0000-00-00 00:00:00'),
(27, 'ru', 'pa', '2017-02-18', 'rupa123@gmail.com', '25f9e794323b453885f5181f1b624d', 'Pending', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
