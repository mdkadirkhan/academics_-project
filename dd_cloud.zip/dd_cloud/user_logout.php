<?php
session_start();



if(isset($_SESSION["dd_cloud_registration_email"]))
{
	unset($_SESSION["dd_cloud_registration_email"]);
}

session_destroy();

header("Location:login.php");


?>