<?php
session_start();



if(isset($_SESSION["admin_name"]))
{
	unset($_SESSION["admin_name"]);
}

session_destroy();

header("Location:../index.html");


?>