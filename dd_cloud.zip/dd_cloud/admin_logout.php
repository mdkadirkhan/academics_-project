<?php

session_start();

if (isset($_SESSION['dd_cloud_admin_uname'])) {
	
	unset($_SESSION['dd_cloud_admin_uname']);

}

session_destroy();

header("Location:admin_login.php");





?>