<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>DeDuplication</title>

<!-- Google fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>

<!-- font awesome -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<!-- bootstrap -->
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />

<!-- animate.css -->
<link rel="stylesheet" href="assets/animate/animate.css" />
<link rel="stylesheet" href="assets/animate/set.css" />

<!-- gallery -->
<link rel="stylesheet" href="assets/gallery/blueimp-gallery.min.css">

<!-- favicon -->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">


<link rel="stylesheet" href="assets/style.css">

</head>

<body>
<div class="topbar animated fadeInLeftBig"></div>

<!-- Header Starts -->
<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-default navbar-fixed-top" role="navigation" id="top-nav">
          <div class="container">
            <div class="navbar-header">
              <!-- Logo Starts -->
              <a class="navbar-brand" href="#home"><img src="images/logo3.png" alt="logo"></a>
              <!-- #Logo Ends -->


              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <?php
include "admin_menu_bar.php";
            ?>            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>
<!-- #Header Starts -->



<div id="home">
<br><br><br><br><br><br>
<h2 align="center"><b>Users Account Status</b></h2>
<?php

include("db_control.php");

if(isset($_GET["update_id"]))
{
$update_id1=$_GET["update_id"];
}
// Select whole data from database

$q=mysql_query("update dd_cloud_registration set dd_cloud_status='Approved' where dd_cloud_registration_id='$update_id1'");

$t= mysql_affected_rows();

// Display the result of data+



  ?>

<?php

if($t>0)
{
?>

<div class="alert alert-success" align="center" style="margin: 15px;">
  <strong>Well Done!! </strong> Account for User ID <?php echo $update_id1;?> is Approved!!
<br><br><a href="admin_acc_status_update.php">Click Here</a> to Approve More Accounts..
</div>
<?php
}
else
{


?>
<div class="alert alert-danger" align="center" style="margin: 15px;">
  <strong>Error!! </strong> Account for User ID <?php echo $update_id1;?> is Not Approved!!<br><br><a href="admin_acc_status_update.php">Click Here</a> to Try Again..

</div>
<?php
}
?>
</div>




<!-- Footer Starts -->
<!-- <div class="footer text-center spacer">
<p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-dribbble fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-linkedin fa-2x"></i></a> </p>
Copyright 2017 Team R.A.N.K . All rights reserved.
</div>
 --><!-- # Footer Ends -->

<!-- jquery -->
<script src="assets/jquery.js"></script>

<!-- wow script -->
<script src="assets/wow/wow.min.js"></script>


<!-- boostrap -->
<script src="assets/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="assets/mobile/touchSwipe.min.js"></script>
<script src="assets/respond/respond.js"></script>

<!-- gallery -->
<script src="assets/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="assets/script.js"></script>



<a href="#home" class="gototop "><i class="fa fa-angle-up  fa-3x"></i></a>
</body>
</html>