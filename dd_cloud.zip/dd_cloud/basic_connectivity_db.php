<?php


$u=$_POST["u"];
$p=$_POST["p"];
//1. establish connecti;on

$conn=mysql_connect("localhost","sample","sample");

if($conn)
{
	echo "connected to database";
}
else
{
	echo "not connected";
	echo mysql_error();
}
//2. select database


 if(mysql_select_db("sample"))
 {
 	echo "database selcted successfully";
 }
//3. fire query


$q=mysql_query("select * from sample1");

$q_insert=mysql_query("insert into sample1 values('$u','$p')");

$q_update=mysql_query("update sample1 set fname='chetan' where lname='kautkar'");

$q_delete=mysql_query("delete from sample1 where fname='chetan'");
//4. display result


while ($temp=mysql_fetch_array($q)) {
	$fname=$temp["fname"];

	$lname=$temp["lname"];

	echo "<h1>The first name and last name are".$fname.$lname;
	echo "<br>";
}
?>