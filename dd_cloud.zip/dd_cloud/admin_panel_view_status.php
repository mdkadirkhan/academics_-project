<?php 

session_start();



if ($_SESSION['admin_username']) {

 ?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>DeDuplication</title>

<!-- Google fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>

<!-- font awesome -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<!-- bootstrap -->
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />

<!-- animate.css -->
<link rel="stylesheet" href="assets/animate/animate.css" />
<link rel="stylesheet" href="assets/animate/set.css" />

<!-- gallery -->
<link rel="stylesheet" href="assets/gallery/blueimp-gallery.min.css">

<!-- favicon -->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">


<link rel="stylesheet" href="assets/style.css">

</head>

<body>
<div class="topbar animated fadeInLeftBig"></div>

<!-- Header Starts -->
<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-default navbar-fixed-top" role="navigation" id="top-nav">
          <div class="container">
            <div class="navbar-header">
              <!-- Logo Starts -->
              <a class="navbar-brand" href="#home"><img src="images/logo3.png" alt="logo"></a>
              <!-- #Logo Ends -->


              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


            <!-- Nav Starts -->
            <?php
include "admin_menu_bar.php";
            ?>           
            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>
<!-- #Header Starts -->



<div id="home">
<br><br><br><br>
<h2 align="center"><b>Users Account Status</b></h2>
<?php

include("db_control.php");

// Select whole data from database

$q=mysql_query("select * from dd_cloud_registration where dd_cloud_status='Pending'");

$t= mysql_affected_rows();

// Display the result of data+



  ?>

<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Registration ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email ID</th>
                <th>Status</th>
                <th>Approve</th>
                <th>Dis-approve</th>
        </thead>
    
        <tbody>
        <?php

while ($temp=mysql_fetch_array($q)) {
  
  $dd_cloud_registration_id=$temp["dd_cloud_registration_id"];
  $dd_cloud_registration_fname=$temp["dd_cloud_registration_fname"];
  $dd_cloud_registration_lname=$temp["dd_cloud_registration_lname"];
  $dd_cloud_registration_email=$temp["dd_cloud_registration_email"];
  $dd_cloud_status=$temp["dd_cloud_status"];
  
        ?>
            <tr>
                <td><?php echo $dd_cloud_registration_id;?></td>
                <td><?php echo $dd_cloud_registration_fname;?></td>
                <td><?php echo $dd_cloud_registration_lname;?></td>
                <td><?php echo $dd_cloud_registration_email;?></td>
                <td><?php echo $dd_cloud_status;?></td>
                <td><button class="btn-success"><a href="admin_acc_status_update.php?update_id=<?php echo $dd_cloud_registration_id;?>">Approve</a></button></td>
                 <td><button class="btn-danger">Approve</button></td>
            </tr>
            <?php

}
            ?>
            </tbody>
            </table>

</div>




<!-- Footer Starts -->
<div class="footer text-center spacer">
<p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-dribbble fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-linkedin fa-2x"></i></a> </p>
Copyright 2017 Team R.A.N.K . All rights reserved.
</div>
 <!-- # Footer Ends

<!-- jquery -->
<script src="assets/jquery.js"></script>

<!-- wow script -->
<script src="assets/wow/wow.min.js"></script>


<!-- boostrap -->
<script src="assets/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="assets/mobile/touchSwipe.min.js"></script>
<script src="assets/respond/respond.js"></script>

<!-- gallery -->
<script src="assets/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="assets/script.js"></script>



<a href="#home" class="gototop "><i class="fa fa-angle-up  fa-3x"></i></a>
</body>
</html>

<?php

}
else
{
  header("Location:index.php");
}

?>