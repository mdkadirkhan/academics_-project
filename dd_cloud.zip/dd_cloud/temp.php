 <?php

$fd=fopen("sample.txt","r");

if($fd)
{
	while (!feof($fd)) {
		$data.=fgets($fd);
	}
echo $data;
$re=base64_encode($data);

echo "<br>Encoded data is<br>";
echo $re;
}

echo "###################################################################";
$fd1=fopen("sample1.txt","r");

if($fd1)
{
	while (!feof($fd1)) {
		$data1.=fgets($fd1);
	}
echo $data1;
$re1=base64_encode($data1);

echo "<br>Encoded data is<br>";
echo $re1;
}

if($re==$re1)

{
	echo "Deduplication in cloud";
}
else
{
	echo "no Deduplication in cloud";
}

$tempfd=fopen("temp.txt",'w');
		
				fwrite($tempfd,'asfsdfsdfsdfs');
		 
	
 ?>