<?php

session_start();

include("db_control.php");

// Select whole data from database

$q=mysql_query("seclect * from dd_cloud_registration");



// Display the result of data+

while ($temp=mysql_fetch_array($q)) {
	
	$dd_cloud_registration_id=$temp["dd_cloud_registration_id"];
	$dd_cloud_registration_fname=$temp["dd_cloud_registration_fname"];
	$dd_cloud_registration_lname=$temp["dd_cloud_registration_lname"];
	$dd_cloud_registration_email=$temp["dd_cloud_registration_email"];
	$dd_cloud_status=$temp["dd_cloud_status"];
	

	
}


?>