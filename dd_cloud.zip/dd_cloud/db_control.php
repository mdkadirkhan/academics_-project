<?php

// 1. Established Connection.
$conn=mysql_connect("localhost","dd_cloud","dd_cloud") or die(mysql_error());


// 2. Connect To Database.

$db=mysql_select_db("dd_cloud") or die(mysql_error());


// 3. 



?>