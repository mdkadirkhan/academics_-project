<?php
error_reporting(0);
require_once('CValidator.php');

$Validator = new Validation();
if($Validator ->validate()){
    
    if (isset($_REQUEST['job_type'])) {
        
        $job_type = $_REQUEST['job_type'];
        header("location:show_details.php?job_type=".$job_type);
    }else if(isset($_REQUEST['submit'])) {

        header("location:show_details.php");
    }
}
$check = trim($Validator ->errmsg);


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <div class="bcontent">
            <div class="hcontent">
                <header>
                    

                        <span class="sitetitle">Jobpply</span>
                    
                    <ul class="menuitem">
                        <li ><a href="" id="selected">Home</a></li>
                        <li><a href="">About</a></li>
                        <li><a href="">Candidates</a></li>
                        <li><a href="">Blog</a></li>
                        <li><a href="">Contact</a></li>
                        <li><a href=""><span  id="postj" >Post a Job</span></a></li>
                        <li><a href=""><span id="wantj">Want a Job</span></a></li>

                    </ul>
                </header>
                <P id="hn">HOME > <span id="njp"> NEW JOB POST</span></P>
                <h1 id="paj">Post A Job</h1>
            </div>

        <div class="form">

            <div class="error" id="errormsg" style="color:red; text-align:center;font-size:13px;visibility:hidden;"></div>
            <?php
            if (!empty($check)) {
                
                echo '<div class="error" id="errormsg" style="color:red; text-align:center;font-size:13px;">'.$check.'</div>';
            }
            
            ?>

            <form action="" onsubmit="return validate()" method="get">
                <input type="checkbox" name="salary[]" value="$500" id=""><label for=""><span id="dollar5">$500</span> For 30 days</label><br>
                <input type="checkbox" name="salary[]" value="$300" id=""><label for=""><span id="dollar3">$300</span> / Monthly Recurring</label><br>
                <label for="" class="fname">Job Title</label><br>
                <input type="text" name="job_title" id="jobtitle" onfocus="hlight(this.id)" onblur="rlight(this.id)" placeholder="eg. Profession UI/UX Designer"><br>
            
                <label for="" class="fname">Company</label><br>
                <input type="text" name="company" id="company" onfocus="hlight(this.id)" onblur="rlight(this.id)" placeholder="eg. Facebook, Inc."><br>
                
                <label for="" class="formt" id="jt">Job Type</label><br>
                <ul id="radiolist">
                    <li><input type="radio" name="post" onchange="radioChange(this)" id="" value="full_time"><label for="">Full Time</label></li>
                    <li><input type="radio" name="post" onchange="radioChange(this)" id="" value="Part_time"><label for="">Part Time</label></li>
                    <li><input type="radio" name="post" onchange="radioChange(this)" id="" value="freelance_time"><label for="">Freelance Time</label></li>
                    <li><input type="radio" name="post" onchange="radioChange(this)" id="" value="internship_time"><label for="">Internship Time</label></li>
                    <li><input type="radio" name="post" onchange="radioChange(this)" id="" value="temporary_time"><label for="">Temporary Time</label></li>
                </ul><br>

                <div style="display:none;" id="textarea">
                    <label class="formt" style="font-size:20px;">Company Profile</label>
                    <textarea cols="30" rows="3"></textarea>
                </div>

                <label for="" class="formt">Location</label><br>
                <input type="text" name="location" id="location" onfocus="hlight(this.id)" onblur="rlight(this.id)" placeholder="Western City, UK"><br>
                
                <label for="" class="formt">Job Description</label><br>
                <textarea name="job_description" id="job_description" onfocus="hlight(this.id)" onblur="rlight(this.id)" cols="30" rows="7"></textarea>
                

                <?php
                if (isset($_REQUEST['job_type'])) {
                    $job_type = $_REQUEST['job_type'];
                    echo '<input type="hidden" name="job_type" value="'.$job_type.'">';
                }
                
                ?>

                <input type="submit" value="Post" name="submit">
                
                
            </form>
        </div>
        <div class="bgcolor">
            
            <div class="contactinfo">
                <h1>Contacts Info</h1><br>
                <h3>Address</h3><br>
                <p>203 Fake St.Mountain View, San Francisco, California, USA</p><br>
                <h3>Phone</h3><br>
                <p>+1 232 3235 324</p><br>
                <h3>Email Address</h3><br>
                <p>[email protected]</p></p>
            </div>

            <div class="moreinfo">
                <h1>More Info</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima cumque quibusdam facere nihil a ab corrupti ducimus ullam fugiat distinctio?</p>
              <br>  <a href="" id="lm">Learn More</a>
            </div>
            
        </div>
        <footer>
            <h2 class="fh2">Subscribe to our Newsletter</h2>
            <p>Far Far away, behind the word mountains, far from the countries vokalia and Consonantia, there live the blind texts, Seperated they live in </p>
            <br>
            <div id="subscribe">

                <input type="email" name="" id="" placeholder="Enter Email Address;">
                <button id="subscribebtn">Subscribe</button>
            </div>
        </footer>
    </div>
</body>

<script type="text/javascript">
    /*Appear When Radio Button is Selected*/
    function radioChange(el){
        document.getElementById('textarea').style.display = el.value == 'yes' ? '' : 'none';
    }

    /*Heighlight Textbox*/
    function hlight (x) {
        document.getElementById(x).style.borderColor="black";
        document.getElementById(x).style.cursor="none";

    }

    function rlight (x) {
        document.getElementById(x).style.borderColor="gray";
        document.getElementById(x).style.cursor="";
    }

    /*Validation of Form*/
    function validate(){

        
        var job_title = document.getElementById('jobtitle');
        var company = document.getElementById('company');
        var location = document.getElementById('location');
        var job_description = document.getElementById('job_description');
        var errormsg = document.getElementById('errormsg');

        var re = /^([a-zA-Z]+\s)*[a-zA-Z]+$/;

    
        
        
        if (job_title.value == "") {
            
            errormsg.innerHTML = 'Field Should Not Empty';
            errormsg.style.visibility="visible";
            job_title.style.border="1px solid red";
            return false;
        }else if (job_title.value.length < 3) {
            errormsg.innerHTML = 'Field Should have at-least 3 character';
            errormsg.style.visibility="visible";
            job_title.style.border="1px solid red";
            return false;
        }else 
        /*Check Number and Special Character*/
        if(!re.test(job_title.value)){
            errormsg.innerHTML = 'Field Should not contain number OR special character';
            errormsg.style.visibility="visible";
            job_title.style.border="1px solid red";
            return false;
        }else if (company.value == "") {
            errormsg.innerHTML = 'Field Should Not Empty';
            errormsg.style.visibility="visible";
            company.style.border="1px solid red";
            return false;
        }else if (company.value.length < 3) {
            errormsg.innerHTML = 'Field Should have at-least 3 character';
            errormsg.style.visibility="visible";
            company.style.border="1px solid red";
            return false;
        }else if (location.value == "") {
            errormsg.innerHTML = 'Field Should Not Empty';
            errormsg.style.visibility="visible";
            location.style.border="1px solid red";
            return false;
        }else if (location.value.length < 3) {
            errormsg.innerHTML = 'Field Should have at-least 3 character';
            errormsg.style.visibility="visible";
            location.style.border="1px solid red";
            return false;
        }else if (job_description.value == "") {
            errormsg.innerHTML = 'Field Should Not Empty';
            errormsg.style.visibility="visible";
            job_description.style.border="1px solid red";
            return false;
        }else if (company.value.length < 3) {
            errormsg.innerHTML = 'Field Should have at-least 3 character';
            errormsg.style.visibility="visible";
            job_description.style.border="1px solid red";
            return false;
        }


        //alert('successfull');
        return true;
    }
</script>
</html>