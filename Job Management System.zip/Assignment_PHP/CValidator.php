<?php
require_once('CPostJob.php');

class Validation extends Database{
    public $errmsg='';
    public function validate(){
        parent::getdata();
        if (isset($_REQUEST['submit'])) {
            if ($_SERVER['REQUEST_METHOD'] == 'GET') {

                
                
                    
                    if (empty($this->job_title)) {
                        $this->errmsg =  'Job Title Field Should Not Empty';
                    }elseif (strlen($this->job_title) < 3) {
                        $this->errmsg = 'Job Title Field Should have at-least 3 character';
                    }elseif (!preg_match('/^([a-zA-Z]+\s)*[a-zA-Z]+$/', trim($this->job_title))) {
                        $this->errmsg = 'Job Title Field Should not contain number OR special character';
                    }elseif (strlen($this->company) < 3) {
                        $this->errmsg = 'Company Field Should have at-least 3 character';
                    }elseif (strlen($this->location) < 3) {
                        $this->errmsg = 'Location Field Should have at-least 3 character';
                    }elseif (strlen($this->job_description) < 3) {
                        $this->errmsg = 'Job Description Field Should have at-least 3 character';
                    }else {
                        return true;
                    }            
                
        }
    }
    
}
}



?>