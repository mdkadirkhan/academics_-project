<?php
session_start();
class A{
    function __construct(){

        $x = 'value';
    }

    public function getdata(){

                
                $this->name = 'Abdul Khan';


    }

    /* public function check(){
        
        //echo $this->testchild();
        if($this->testchild()){
            echo 'empty';
        }else {
            echo 'string';
        }
    } */
    
    public function check(){
        
        //echo $this->testchild();
        echo $this->name;
    }

    
}

class Child extends A{
    public function showdata() {
        parent::getdata();
  
                echo $this->name;
                $_SESSION[] = $this->name;
                return true;


       
    }



    /* public function testchild(){
        $str = 'jkldjf';
        if (empty($str)) {
            return false;
            
        }else {
            return true;
        }
        
    } */
}


$obj = new Child();
$p= new A();




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="" method="get">
        <input type="submit" value="Submit" name="submit">
    </form>
</body>
</html>

