<?php
require_once('CPostJob.php');
$fech = new Database();
if (isset($_REQUEST['id'])) {
    
    $id = $_GET['id'];
    
    $fech->fetched_data($id);
}elseif (isset($_REQUEST['job_type'])) {
    $job_type = $_REQUEST['job_type'];
    $fech->fetched_data($job_type);

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Job Listing</title>
</head>
<body>
<form action="download.php" method="post" onsubmit="return confirmation()">
    <?php
    if (isset($_REQUEST['id'])) {
        
        echo '<input type="submit" id="export" name="export" value="CSV Export">';
        echo '<input type="hidden" name="job_type" value="'.$id.'">';
    }elseif (isset($_REQUEST['job_type'])) {
       echo '<input type="submit" value="Delete" id="Delete" name="delete">';
       echo '<input type="hidden" name="job_type" value="'.$job_type.'">';
      
        
    }
    ?>
</form>

    <script>
        var export = document.getElementById('export');
        if (export.value == "CSV Export") {
            
        function confirmation(){
            if(window.confirm('Sure Want to Delete Data!!')){
                return true
            }
            return false;
        }
        }
    </script>

</body>
</html>