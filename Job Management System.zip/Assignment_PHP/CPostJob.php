<?php
session_start();
require_once('config.php');
class Database{
    public function __construct(){
        try {
        $dsn = 'pgsql:host=localhost;dbname=xento_db';
        $user = 'postgres';
        $password = '123';

        $this->db = new PDO($dsn,$user,$password);
     

        } catch (PDOException $e) {
            die('Connection Failed </br>'.$e->getMessage());
        }
    }


    public function getdata(){
        if (isset($_REQUEST['submit'])) {
            if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                
                $this->salary = $_REQUEST['salary'];
                $this->job_title = $_REQUEST['job_title'];
                $this->company = $_REQUEST['company'];
                $this->location = $_REQUEST['location'];
                $this->job_description = $_REQUEST['job_description'];
                $this->job_type = $_REQUEST['post'];

               

              
                $_SESSION['salary'] = $this->salary;
                $_SESSION['job_title'] = $this->job_title;
                $_SESSION['company'] = $this->company;
                $_SESSION['location'] = $this->location;
                $_SESSION['job_description'] = $this->job_description;
                $_SESSION['job_type'] = $this->job_type;
                

            }else {
                echo 'Request Method is Invalid';
            }
        }
    }

    public function showdata(){
        echo 'Field Name : Submitted Data'.'<br>';
        echo 'Form Post Method : '.$_SERVER['REQUEST_METHOD'].'<br>';
        echo 'salary : '.implode(', ',$this->salary).'<br>';
        echo 'Job_Title : '.$this->job_title.'<br>';
        echo 'Company : '.$this->company.'<br>';
        echo 'location : '.$this->location.'<br>';
        echo 'job_description : '.$this->job_description.'<br>';

    }

    public function insert($data){
       
        
        $this->job_title = $data['job_title'];
        $this->salary = implode(', ',$data['salary']);
        $this->company = $data['company'];
        $this->locations = $data['location'];
        $this->job_description = $data['job_description'];
        $this->job_type = $data['job_type'];
        
      

        $sql_insert = "INSERT INTO jobs(job_title, salary, company, locations, descriptions, job_type) 
        VALUES('$this->job_title', '$this->salary', '$this->company', '$this->locations', '$this->job_description', '$this->job_type' )"; 
        
        $result = $this->db->query($sql_insert);
      

        if ($result) {
            echo '<h3>Data Inserted Successfully</h3>';
        }else {
            echo '<h3>Data not Inserted</h3>';
        }
    }

    public function fetched_data($field){

        $sql_select ="SELECT * FROM jobs WHERE job_type='$field'";
        $result = $this->db->query($sql_select);
        $fetched = $result->fetchAll(PDO::FETCH_ASSOC);
        if ($result) {
            echo '<h3>Fetched Data From Jobs Table..</h3>';
            echo '<table border="1">
            <thead>
            <tr>
                <th>Salary</th>  
                <th>Job Title</th>  
                <th>Company</th>  
                <th>Location</th>  
                <th>Description</th>  
                <th>Job Type</th>  
                    </tr>
                    </thead> 
                    ';
                    
                    foreach ($fetched as $fetch_key =>$fetch_value) {
                        
                        echo '<tr>';
                        foreach ($fetched[$fetch_key] as $value) {
                
                            echo "<td>$value</td>";
                        }
                        echo '</tr>';
        }
        
        echo '</table>';
    }
}

    public function export($job_type){
    
        header('Content-type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=data.csv');
        $output = fopen('php://output','w');
        fputcsv($output, array('salary', 'job_title', 'company', 'locations', 'descriptions', 'job_type' ));
        
        $sql_select ="SELECT * FROM jobs WHERE job_type='$job_type' ";
        $result = $this->db->query($sql_select);
        $fetched = $result->fetchAll(PDO::FETCH_ASSOC);
        foreach ($fetched as $fetch_key =>$fetch_value) {
            fputcsv($output, $fetched[$fetch_key]);
        }   
        fclose($output);
    }

    public function update($data, $job_type){
        
       

        $this->job_titles = $data['job_title'];
        $this->salarys = implode(', ',$data['salary']);
        $this->companys = $data['company'];
        $this->locationss = $data['location'];
        $this->job_descriptions = $data['job_description'];
        $this->job_types = $data['job_type'];

       

        $sql_update = "UPDATE jobs
                        SET salary='$this->salarys', job_title='$this->job_titles', company='$this->companys', locations='$this->locationss', descriptions='$this->job_descriptions', job_type='$this->job_types'
                        WHERE job_type='$job_type'
                        ";
        $result=$this->db->query($sql_update);

        if ($result) {
            echo '<h3>updated successfully</h3>';
        }else {
            echo '<h3>not updated</h3>';
        }
        
    }
    
    public function delete($job_type){
        
        $sql_delete = "DELETE FROM jobs
                        WHERE job_type='$job_type'
                        ";

$result = $this->db->query($sql_delete);
        if ($result) {
        echo '<h3>Data Deleted</h3>';
            return true;
        }else {
            echo '<h3>Some went wrong while deleting a data</h3>';
        }
    }
    
}





?>