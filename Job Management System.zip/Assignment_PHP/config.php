
<?php

try {
        $dsn = 'pgsql:host=localhost;dbname=xento_db';
        $user = 'postgres';
        $password = '123';

        $db = new PDO($dsn,$user,$password);
        

        } catch (PDOException $e) {
            die('Connection Failed </br>'.$e->getMessage());
        }

        $ak ='abdul';

?>