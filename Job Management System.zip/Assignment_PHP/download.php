<?php
    require_once('CPostJob.php');
    $ex = new Database();
if (isset($_REQUEST['export'])) {

    $job_type = $_REQUEST['job_type'];

    $ex->export($job_type);

    

}elseif (isset($_REQUEST['delete'])) {

    $r = $ex->delete($_REQUEST['job_type']);
   
    header('location: Assignment HTMLCSS.3.php?deletevalue='.$r);
}


?>

