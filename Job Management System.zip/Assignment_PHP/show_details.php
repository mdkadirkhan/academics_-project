<?php
error_reporting(0);
require_once('CPostJob.php');


    echo 'Field Name : Submitted Data'.'<br>';
        echo 'Form Post Method : '.$_SERVER['REQUEST_METHOD'].'<br>';
        echo 'salary : '.implode(', ',$_SESSION['salary']).'<br>';
        echo 'Job_Title : '.$_SESSION['job_title'].'<br>';
        echo 'Company : '. $_SESSION['company'].'<br>';
        echo 'location : '. $_SESSION['location'].'<br>';
        echo 'job_description : '. $_SESSION['job_description'].'<br>';
        echo 'Job type : '.  $_SESSION['job_type'].'<br>';



$db = new Database;




if (isset($_REQUEST['job_type'])) {
    
    
    $db->update($_SESSION, $_REQUEST['job_type']);
    
}else {
    $db->insert($_SESSION);
   
    
}



?>