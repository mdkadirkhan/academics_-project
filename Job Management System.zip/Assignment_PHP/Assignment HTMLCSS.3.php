




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="bcontent">
        <div class="hcontent">
            <header>


                <span class="sitetitle">Jobpply</span>

                <ul class="menuitem">
                    <li><a href="" id="selected">Home</a></li>
                    <li><a href="">About</a></li>
                    <li><a href="">Candidates</a></li>
                    <li><a href="">Blog</a></li>
                    <li><a href="">Contact</a></li>
                    <li><a href=""><span id="postj">Post a Job</span></a></li>
                    <li><a href=""><span id="wantj">Want a Job</span></a></li>

                </ul>
            </header>
            <P id="hn">HOME > <span id="njp"> JOB POSTS</span></P>
            <h1 id="paj">Apply Jobs</h1>
        </div>

        <div class="table1">
            <table >
                <thead>
                    <caption>Recently Added Jobs</caption>



                    <th>Hot Jobs</th>


                </thead>
                <tbody>

                    <tr>
                        <td>
                        <div>
                            <p class="jobs" onclick="openwindow1()">Frontend Development
                                <span class="duration" id="partime">Partime</span>
                            </p>
                                <span class="jobl"><a href="job_listing.php?id=Part_time">Open</a></span>
                                <span class="jobl"><a href="./Assignment HTMLCSS.2.php?job_type=Part_time">Edit</a></span>
                                <span class="jobl"><a href="./job_listing.php?job_type=Part_time">Delete</a></span>
                        </div>
                            <p class="layerp"><img src="assets/baseline-layers-24px.svg" class="layer" alt="" srcset="">
                                FACEBOOK, INC. 
                            </p>
                            <p class="locationp"><img src="assets/baseline-my_location-24px.svg" class="location" alt="" srcset="">
                                WESTERN CITY, UK 
                            </p>
                    
                        </td>
                        <td><span class="heart">&hearts;</span><a href="" class="aj">Apply Job</a></td>
                    
                    </tr>
                    <tr>
                        <td>
                            <div>
                            <p class="jobs" onclick="openwindow2()">Full Stack Developer
                                <span class="duration" id="fulltime">Fulltime</span>
                            </p>
                            <span class="jobl"><a href="job_listing.php?id=full_time">Open</a></span>
                            <span class="jobl"><a href="./Assignment HTMLCSS.2.php?job_type=full_time">Edit</a></span>
                            <span class="jobl"><a href="./job_listing.php?job_type=full_time">Delete</a></span>
                            </div>
                            <p class="layerp"><img src="assets/baseline-layers-24px.svg" class="layer" alt="" srcset="">
                                GOOGLE, INC. 
                            </p>
                            <p class="locationp"><img src="assets/baseline-my_location-24px.svg" class="location" alt="" srcset="">
                                WESTERN CITY, UK 
                            </p>
                    
                        </td>
                        <td><span class="heart">&hearts;</span><a href="" class="aj">Apply Job</a></td>
                    
                    </tr>
                    <tr>
                        <td>
                            <div>
                            <p class="jobs" onclick="openwindow3()">Open Source Interactive Developer
                                <span class="duration" id="freelance">Freelance</span>
                            </p>
                            <span class="jobl"><a href="job_listing.php?id=freelance_time">Open</a></span>
                            <span class="jobl"><a href="./Assignment HTMLCSS.2.php?job_type=freelance_time">Edit</a></span>
                            <span class="jobl"><a href="./job_listing.php?job_type=freelance_time">Delete</a></span>
                            
                            </div>
                            <p class="layerp"><img src="assets/baseline-layers-24px.svg" class="layer" alt="" srcset="">
                                NEW YOURK TIMES 
                            </p>
                            <p class="locationp"><img src="assets/baseline-my_location-24px.svg" class="location" alt="" srcset="">
                                WESTERN CITY, UK 
                            </p>
                    
                        </td>
                        <td><span class="heart">&hearts;</span><a href="" class="aj">Apply Job</a></td>
                    
                    </tr>
                    <tr>
                        <td>
                            <div>
                            <p class="jobs" onclick="openwindow2()">Full Stack Developer
                                <span class="duration" id="internship">Internship</span>
                            </p>
                            <span class="jobl"><a href="job_listing.php?id=internship_time">Open</a></span>
                            <span class="jobl"><a href="./Assignment HTMLCSS.2.php?job_type=internship_time">Edit</a></span>
                            <span class="jobl"><a href="./job_listing.php?job_type=internship_time">Delete</a></span>
                            </div>
                            <p class="layerp"><img src="assets/baseline-layers-24px.svg" class="layer" alt="" srcset="">
                                FACEBOOK, INC. 
                            </p>
                            <p class="locationp"><img src="assets/baseline-my_location-24px.svg" class="location" alt="" srcset="">
                                WESTERN CITY, UK 
                            </p>
                    
                        </td>
                        <td><span class="heart">&hearts;</span><a href="" class="aj">Apply Job</a></td>
                    
                    </tr>
                    <tr>
                        <td>
                            <div>
                            <p class="jobs" onclick="openwindow3()">Open Source Interactive Developer
                                <span class="duration" id="temporary">Temporary</span>
                            </p>
                            <span class="jobl"><a href="job_listing.php?id=temporary_time">Open</a></span>
                            <span class="jobl"><a href="./Assignment HTMLCSS.2.php?job_type=temporary_time">Edit</a></span>
                            <span class="jobl"><a href="./job_listing.php?job_type=temporary_time">Delete</a></span>
                            </div>
                            <p class="layerp"><img src="assets/baseline-layers-24px.svg" class="layer" alt="" srcset="">
                                NEW YOURK TIMES
                            </p>
                            <p class="locationp"><img src="assets/baseline-my_location-24px.svg" class="location" alt="" srcset="">
                                WESTERN CITY, UK
                            </p>
                    
                        </td>
                        <td><span class="heart">&hearts;</span><a href="" class="aj">Apply Job</a></td>
                    
                    </tr>

                    <tr>
                        <td>
                            <div>
                            <p class="jobs" onclick="openwindow2()">Full Stack Developer
                                <span class="duration" id="fulltime">Fulltime</span>
                            </p>
                            <span class="jobl"><a href="job_listing.php?id=full_time">Open</a></span>
                            <span class="jobl"><a href="./Assignment HTMLCSS.2.php?job_type=full_time">Edit</a></span>
                            <span class="jobl"><a href="./job_listing.php?job_type=full_time">Delete</a></span>
                            </div>
                            <p class="layerp"><img src="assets/baseline-layers-24px.svg" class="layer" alt="" srcset="">
                                GOOGLE, INC.
                            </p>
                            <p class="locationp"><img src="assets/baseline-my_location-24px.svg" class="location" alt="" srcset="">
                                WESTERN CITY, UK
                            </p>
                    
                        </td>
                        <td><span class="heart">&hearts;</span><a href="" class="aj">Apply Job</a></td>
                    
                    </tr>
                    <tr>
                        <td>
                            <div>
                            <p class="jobs" onclick="openwindow3()">Open Source Interactive Developer
                                <span class="duration" id="freelance">Freelance</span>
                            </p>
                            <span class="jobl"><a href="job_listing.php?id=freelance_time">Open</a></span>
                            <span class="jobl"><a href="./Assignment HTMLCSS.2.php?job_type=freelance_time">Edit</a></span>
                            <span class="jobl"><a href="./job_listing.php?job_type=freelance_time">Delete</a></span>
                            </div>
                            <p class="layerp"><img src="assets/baseline-layers-24px.svg" class="layer" alt="" srcset="">
                                NEW YOURK TIMES
                            </p>
                            <p class="locationp"><img src="assets/baseline-my_location-24px.svg" class="location" alt="" srcset="">
                                WESTERN CITY, UK
                            </p>
                    
                        </td>
                        <td><span class="heart">&hearts;</span><a href="" class="aj">Apply Job</a></td>
                    
                    </tr>
                    <tr>
                        <td>
                            <div>
                            <p class="jobs" onclick="openwindow2()">Full Stack Developer
                                <span class="duration" id="internship">Internship</span>
                            </p>
                            <span class="jobl"><a href="job_listing.php?id=internship_time">Open</a></span>
                            <span class="jobl"><a href="./Assignment HTMLCSS.2.php?job_type=internship_time">Edit</a></span>
                            <span class="jobl"><a href="./job_listing.php?job_type=internship_time">Delete</a></span>
                            </div>
                            <p class="layerp"><img src="assets/baseline-layers-24px.svg" class="layer" alt="" srcset="">
                                FACEBOOK, INC.
                            </p>
                            <p class="locationp"><img src="assets/baseline-my_location-24px.svg" class="location" alt="" srcset="">
                                WESTERN CITY, UK
                            </p>
                    
                        </td>
                        <td><span class="heart">&hearts;</span><a href="" class="aj">Apply Job</a></td>
                    
                    </tr>
                    <tr>
                        <td>
                        <div>
                            <p class="jobs" onclick="openwindow3()">Open Source Interactive Developer
                                <span class="duration" id="temporary">Temporary</span>
                            </p>
                            <span class="jobl"><a href="job_listing.php?id=temporary_time">Open</a></span>
                            <span class="jobl"><a href="./Assignment HTMLCSS.2.php?job_type=temporary_time">Edit</a></span>
                            <span class="jobl"><a href="./job_listing.php?job_type=temporary_time">Delete</a></span>
                        </div>
                            <p class="layerp"><img src="assets/baseline-layers-24px.svg" class="layer" alt="" srcset="">
                                NEW YOURK TIMES
                            </p>
                            <p class="locationp"><img src="assets/baseline-my_location-24px.svg" class="location" alt="" srcset="">
                                WESTERN CITY, UK
                            </p>
                    
                        </td>
                        <td><span class="heart">&hearts;</span><a href="" class="aj">Apply Job</a></td>
                    
                    </tr>

    
                </tbody>
            </table>

            <div class="circlebox">
                <div class="numberCircle"> < </div>
                <div class="numberCircle" id="pageone">1</div>
                <div class="numberCircle">2</div>
                <div class="numberCircle">3</div>
                <div class="numberCircle">4</div>
                <div class="numberCircle">5</div>
                <div class="numberCircle">></div>

            </div>
        </div>

        <footer>
            <h2 class="fh2">Subscribe to our Newsletter</h2>
            <p>Far Far away, behind the word mountains, far from the countries vokalia and Consonantia, there live the
                blind texts, Seperated they live in </p>
            <br>
            <div id="subscribe">

                <input type="email" name="" id="" placeholder="Enter Email Address;">
                <button id="subscribebtn">Subscribe</button>
            </div>
        </footer>
    </div>
</body>

<?php

if (isset($_REQUEST['deletevalue'])) {
    echo '
    <script>
        alert("Data Deleted Succesfully");
    </script>
        ';
}



?>
<script type="text/javascript">
    var mywindow;
    function openwindow1 () {
        mywindow = window.open('frontend_description.html');
    }
    function openwindow2 () {
        mywindow = window.open('fullstack_developer.html');
    }
    function openwindow3 () {
        mywindow = window.open('opensource_developer.html');
    }
</script>
</html>