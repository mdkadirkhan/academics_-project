<?php
include_once("config/config.php");

$a[0] = array(
    "one" => 1,
    "two" => 2,
    "three" => 3,
    "ten" => 10,
);
$a[1] = array(
    "one" => 1,
    "two" => 2,
    "three" => 3,
    "ten" => 10,
);

foreach($a[0] as $k => $v){
    echo "$a[$k][0] => $v....";
}

foreach($a[1] as $k => $v){
    echo "$a[$k][1] => $v....";
}

?>