<!-- Registration -->
<?php

include_once('config/config.php');



if (isset($_POST['register'])) {

	$user_name = $_POST['name'];
	$user_email = $_POST['email'];
	$user_pass = md5($_POST['password']);
	$user_confirm_pass = $_POST['confirm'];


	$query = "SELECT user_registration_email FROM user_registration WHERE user_registration_email ='$user_email'";
	$fire = mysqli_query($conn,$query);

	if ($row=mysqli_num_rows($fire) >0) {
                
		$result = "This email is already registered.";
	} 
	else {
		$sql = "INSERT INTO user_registration(user_registration_name,user_registration_email,user_registration_pass)VALUES('$user_name','$user_email','$user_pass')";
		$result = "";

		if (mysqli_query($conn,$sql)) {
			$result = "Successfully Registered! Login Now!";
			
		}
		else{
			$result = "Failed to Register!";
			
		}
		
	}

}

?>

<!-- Login Process -->
<?php 
if (isset($_POST['login'])) {

	$user_email = mysqli_real_escape_string($conn,trim($_POST['username']));
	$user_pass = mysqli_real_escape_string($conn,md5(trim($_POST['password'])));

	$query = "SELECT * FROM user_registration WHERE user_registration_email='$user_email' AND user_registration_pass='$user_pass'";
	
	$fire = mysqli_query($conn,	$query);

//	Fetching Data From Database
	if($rows=mysqli_num_rows($fire) == 1){

		$customer = mysqli_fetch_assoc($fire);
		$customer_name = $customer['user_registration_name'];

		session_start();
			$_SESSION['is_login'] = true;
			$_SESSION['customer_name'] = $customer_name;
			$_SESSION['user_email'] = $user_email;
			
			header('location:user_dashboard.php');
			
	}else{

		$result = "Invalid Username or Password" ;
	}
	// ...Fetching Data From Database

	
	}



?>









<!DOCTYPE html>
<html lang="en">
<head>
	<title>Electro Store </title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Electro Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta tag Keywords -->

	<!-- Custom-Files -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!-- Bootstrap css -->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!-- Main css -->
	<link rel="stylesheet" href="css/fontawesome-all.css">
	<!-- Font-Awesome-Icons-CSS -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<!-- pop-up-box -->
	<link href="css/menu.css" rel="stylesheet" type="text/css" media="all" />
	<!-- menu style -->
	<!-- //Custom-Files -->

	<!-- web fonts -->
	<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&amp;subset=latin-ext" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	    rel="stylesheet">
	<!-- //web fonts -->

</head>
<body>



    <!-- top-header -->
	<div class="agile-main-top">
		<div class="container-fluid">
			<div class="row main-top-w3l py-2">
				<div class="col-lg-4 header-most-top">
					<p class="text-white text-lg-left text-center">Offer Zone Top Deals & Discounts
						<i class="fas fa-shopping-cart ml-1"></i>
					</p>
				</div>
				<div class="col-lg-8 header-right mt-lg-0 mt-2">
					<!-- header lists -->
					<ul>
						
						<li class="text-center border-right text-white">
							<a href="#" class="text-white">
								<i class="fas fa-truck mr-2"></i>Track Order</a>
						</li>
						<li class="text-center border-right text-white">
							<i class="fas fa-phone mr-2"></i> 0253-445588
						</li>
						<li class="text-center border-right text-white">
							<a href="#" data-toggle="modal" data-target="#exampleModal" class="text-white">
								<i class="fas fa-user mr-2"></i> 
								<?php 
									session_start();
									if(isset($_SESSION['is_login']) == true) {?> 
									<a href="logout.php" class="text-white"> Log Out </a>
									
									<?php } else{?>
										Login </a> <?php } ?>

						</li>
						<li class="text-center text-white">
							
								<i class="fas fa-user-plus mr-2"></i>
								
								<?php 
				
									if(isset($_SESSION['is_login']) == true) {
										
									echo "Welcome ".$_SESSION['customer_name'];	?> 
									
									<?php } else{?>
										<a href="#" data-toggle="modal" data-target="#exampleModal2" class="text-white">
										Register </a> <?php } ?>
						</li>

						<li class="text-center border-left text-white">
							<a href="admin/html/orders.php" class="text-white">
								<i class="fas fa-user-circle mr-2"></i>Admin</a>
						</li>
					</ul>
					<!-- //header lists -->
				</div>
			</div>
		</div>
	</div>


	<!-- modals -->
	<!-- log in -->
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-center">Log In</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="#" method="post">
						<div class="form-group">
							<label class="col-form-label">Username</label>
							<input type="text" class="form-control" placeholder=" " name="username" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Password</label>
							<input type="password" class="form-control" placeholder=" " name="password" required="">
						</div>
						<div class="right-w3l">
							<input type="submit" class="form-control" value="Log in" name="login" >
						</div>
						<div class="sub-w3l">
							<div class="custom-control custom-checkbox mr-sm-2">
								<input type="checkbox" class="custom-control-input" id="customControlAutosizing">
								<label class="custom-control-label" for="customControlAutosizing">Remember me?</label>
							</div>
						</div>
						<p class="text-center dont-do mt-3">Don't have an account?
							<a href="#" data-toggle="modal" data-target="#exampleModal2">
								Register Now</a>
						</p>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- register -->
	<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-hidden="false">
		<div class="modal-dialog" role="documen">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Register</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="#" method="POST">
						<div class="form-group">
							<label class="col-form-label">Your Name</label>
							<input type="text" class="form-control" placeholder=" " name="name" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Email</label>
							<input type="email" class="form-control" placeholder=" " name="email" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Password</label>
							<input type="password" class="form-control" placeholder=" " name="password" id="password1" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Confirm Password</label>
							<input type="password" class="form-control" placeholder=" " name="confirm" id="password2"  required="">
						</div>



						<div class="right-w3l">
							<input type="submit" class="form-control" value="Register" name="register" data-toggle="modal" data-target="">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- //modal -->

	<!-- Modal of Registration Message-->
<div class="modal fade" id="success_alert" tabindex="-1" role="dialog"  aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-body alert-success">
				<?php echo $result; ?>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		  <span aria-hidden="true">&times;</span>
		</button>
			</div>
		</div>
	</div>
</div>



	<!-- //top-header -->

	<!-- header-bottom-->
	<div class="header-bot">
		<div class="container">
			<div class="row header-bot_inner_wthreeinfo_header_mid">
				<!-- logo -->
				<div class="col-md-3 logo_agile">
					<h1 class="text-center">
						<a href="index.php" class="font-weight-bold font-italic">
							<img src="images/logo2.png" alt=" " class="img-fluid">Electro Store
						</a>
					</h1>
				</div>
				<!-- //logo -->
				<!-- header-bot -->
				<div class="col-md-9 header mt-4 mb-md-0 mb-4">
					<div class="row">
						<!-- search -->
						<div class="col-10 agileits_search">
							<form class="form-inline" action="#" method="post">
								<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" required>
								<button class="btn my-2 my-sm-0" type="submit">Search</button>
							</form>
						</div>
						<!-- //search -->
						
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //header-bottom -->
	<!-- navigation -->
	<div class="navbar-inner">
		<div class="container">
			<nav class="navbar navbar-expand-lg navbar-light bg-light">
				<div class="agileits-navi_search">
					<form action="#" method="post">
						<select id="agileinfo-nav_search" name="agileinfo_search" class="border" required="">
							<option value="">All Categories</option>
							<option value="Televisions">Televisions</option>
							<option value="Headphones">Headphones</option>
							<option value="Computers">Computers</option>
							<option value="Appliances">Appliances</option>
							<option value="Mobiles">Mobiles</option>
							<option value="Fruits &amp; Vegetables">Tv &amp; Video</option>
							<option value="iPad & Tablets">iPad & Tablets</option>
							<option value="Cameras & Camcorders">Cameras & Camcorders</option>
							<option value="Home Audio & Theater">Home Audio & Theater</option>
						</select>
					</form>
				</div>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav ml-auto text-center mr-xl-5">
						<li class="nav-item active mr-lg-2 mb-lg-0 mb-2">
							<a class="nav-link" href="index.php">Home
								<span class="sr-only">(current)</span>
							</a>
						</li>
						<li class="nav-item dropdown mr-lg-2 mb-lg-0 mb-2">
							<a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								Electronics
							</a>
							<div class="dropdown-menu">
								<div class="agile_inner_drop_nav_info p-4">
									<h5 class="mb-3">Mobiles, Computers</h5>
									<div class="row">
										<div class="col-sm-6 multi-gd-img">
											<ul class="multi-column-dropdown">
												<li>
													<a href="product.php">All Mobile Phones</a>
												</li>
												<li>
													<a href="product.php">All Mobile Accessories</a>
												</li>
												<li>
													<a href="product.php">Cases & Covers</a>
												</li>
												<li>
													<a href="product.php">Screen Protectors</a>
												</li>
												<li>
													<a href="product.php">Power Banks</a>
												</li>
												<li>
													<a href="product.php">All Certified Refurbished</a>
												</li>
												<li>
													<a href="product.php">Tablets</a>
												</li>
												<li>
													<a href="product.php">Wearable Devices</a>
												</li>
												<li>
													<a href="product.php">Smart Home</a>
												</li>
											</ul>
										</div>
										<div class="col-sm-6 multi-gd-img">
											<ul class="multi-column-dropdown">
												<li>
													<a href="product.php">Laptops</a>
												</li>
												<li>
													<a href="product.php">Drives & Storage</a>
												</li>
												<li>
													<a href="product.php">Printers & Ink</a>
												</li>
												<li>
													<a href="product.php">Networking Devices</a>
												</li>
												<li>
													<a href="product.php">Computer Accessories</a>
												</li>
												<li>
													<a href="product.php">Game Zone</a>
												</li>
												<li>
													<a href="product.php">Software</a>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</li>
			
						<li class="nav-item mr-lg-2 mb-lg-0 mb-2">
							<a class="nav-link" href="about.php">About Us</a>
						</li>
						<li class="nav-item mr-lg-2 mb-lg-0 mb-2">
							<a class="nav-link" href="product.php">New Arrivals</a>
						</li>
					
						<li class="nav-item">
							<a class="nav-link" href="contact.php">Contact Us</a>
						</li>
					</ul>
				</div>
			</nav>
		</div>
	</div>
	<!-- //navigation -->

	<script src="js/jquery-2.2.3.min.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>



<?php
    if (isset($_POST['register']) || isset($_POST['login'])) {
        
		echo "<script>$('#success_alert').modal('show');  </script>";
    }

?>