<?php

    /* session_start();

    if (isset($_POST['submit'])) {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $mobno = $_POST['mobno'];


        $_SESSION['now'] = true;

        $_SESSION['details'] = array($firstname,$lastname,$mobno);


    } */


?>










<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
    <form action="page2.php" method="post">
        First Name : <input type="text" name="firstname" id=""></br>
        Last Name : <input type="text" name="lastname" id=""></br>
        Mob No. :   <input type="text" name="mobno" id=""></br>
        <input type="submit" value="Submit" name="submit" >
    </form>
</body>
</html>

