<?php
session_start();
include_once("../config/config.php");

if (isset($_POST['submit'])) {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $mobno = $_POST['mobno'];


    $_SESSION['now'] = true;

    $_SESSION['details'] = array($firstname,$lastname,$mobno);


}
if (isset($_SESSION['now']) == true) {



    # code...
    foreach ($_SESSION['details'] as $key => $value) {
        echo "Key :".$key." Values :".$value;
        echo "</br>";
    }
    
    echo "</br>".$key[0];
    echo $value;
    $firstname = $_SESSION['details'][0];
    $lastname = $_SESSION['details'][1];
    $mobno = $_SESSION['details'][2];
}
else{
    echo "Session is not applied.";
}




/* $query = "INSERT INTO test(first_name,last_name,mob_no)  VALUES('$firstname','$lastname','$mobno') ";
$fire = mysqli_query($conn,$query);

if ($fire) {
    echo "Query is Successfully Fired.";
}
else{
    echo "Something Went Wrong !!!";
} */ 



?>