
<?php
include_once("header.php");
include_once("../../config/config.php");
?>



       


       <div id="page-wrapper">

       
        <div class="container-fluid">
            
            <!-- /row -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="white-box">
                        <h3 class="box-title">User Registered</h3>
                        
                        <div class="table-responsive">

                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>User ID</th>
                                        <th>User Name</th>
                                        <th>User E-mail</th>
                                        <th>User Password</th>
                                        <th>Action</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>


                                <?php
        

                                    $query = "SELECT * FROM user_registration";
                                    $fire = mysqli_query($conn,$query);

                                    while ($row = mysqli_fetch_array($fire)) {
                                        
                                         $user_id = $row['user_registration_id'];
                                         $user_name = $row['user_registration_name'];
                                         $user_email = $row['user_registration_email'];
                                         $user_password = $row['user_registration_pass'];
                                    

                                ?>

                                    <tr>
                                        <td><?php echo $user_id; ?></td>
                                        <td><?php echo $user_name; ?></td>
                                        <td><?php echo $user_email; ?></td>
                                        <td><?php echo $user_password; ?></td>
                                        <td><a class="btn  btn-danger btn-sm " role="button" href="delete.php?id=<?php echo $user_id; ?>"> Reject </a></td>
                                        
                                    </tr>

                                <?php  } ?>


                                
                                   
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>


    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="js/jquery-2.2.3.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>

    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>

</body>
</html>
