<?php

include_once("../../config/config.php");

$getid = $_GET['id'];



    $query = "DELETE FROM user_registration WHERE user_registration_id = $getid";
    $fire = mysqli_query($conn,$query);
    
    header("location:user_registered.php");


?>