
<?php

include_once("header.php");
include_once("../../config/config.php");
?>


<!DOCTYPE html>
<html lang="en">

<head>
 
    <style>
    
        img{
            width : 18%;
        }

    </style>

</head>
<body>
       


       <div id="page-wrapper">

       
        <div class="container-fluid">
            
            <!-- /row -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="white-box">
                        <h3 class="box-title">Products</h3>
                        
                        <div class="table-responsive">

                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>MRP</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th>Images</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>


                                <?php
        

                                    $query = "SELECT * FROM products";
                                    $fire = mysqli_query($conn,$query);

                                    while ($row = mysqli_fetch_array($fire)) {
                                        
                                         $product_id = $row['product_id'];
                                         $product_name = $row['product_name'];
                                         $product_price = $row['product_price'];
                                         $product_MRP = $row['product_MRP'];
                                         $product_brand = $row['product_brand'];
                                         $product_categories = $row['product_categories'];
                                         $product_image = $row['product_image'];
                                    

                                ?>

                                    <tr>
                                        <td><?php echo $product_id; ?></td>
                                        <td><?php echo $product_name; ?></td>
                                        <td><?php echo $product_price; ?></td>
                                        <td><del><?php echo $product_MRP; ?></del></td>
                                        <td><?php echo $product_brand; ?></td>
                                        <td><?php echo $product_categories; ?></td>
                                        <td><?php echo '<img src="data:image/png;base64,'.base64_encode($product_image).'"/>'; ?></td>
                                        
                                    </tr>

                                <?php  } ?>
                                   
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>


    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>

</body>
</html>







<!-- *********************************************************************** -->












<!-- ****************************************************************************** -->