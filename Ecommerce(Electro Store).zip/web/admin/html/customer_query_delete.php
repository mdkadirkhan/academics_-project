<?php

include_once("../../config/config.php");

$getid = $_GET['id'];

    $query = "DELETE FROM customer_query WHERE id = $getid";
    $fire = mysqli_query($conn,$query);
    
    header("location:customer_query.php");

?>