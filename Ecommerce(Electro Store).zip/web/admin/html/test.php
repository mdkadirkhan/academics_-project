
<?php

    include_once("../../config/config.php");
    $msg = "";
    if (isset($_GET['submit'])) {
        $user_name = mysqli_real_escape_string($conn,$_GET['name']);
        $user_email = $_GET['email'];
        $user_pass = mysqli_real_escape_string($conn,$_GET['pass']);
      
        
        $query = "SELECT user_registration_email FROM user_registration WHERE user_registration_email ='$user_email'";
        $fire = mysqli_query($conn,$query);
        
     /*    if ($user_name="" || $user_email="" || $user_pass = "" ) {
            $msg = "please check your input";
        }
        else{
            $query = "SELECT user_registration_email FROM user_registration WHERE user_registration_email ='$user_email'";
            $fire = mysqli_query($conn,$query);

            if ($row=mysqli_num_rows($fire) > 0){
                $msg = "email is already exist.";
            }
        } */


        if ($row=mysqli_num_rows($fire) >0) {
                
                echo "This email is already registered.";
            } 
            else {
                echo "This email is not registered.";
                
            }
            
    }
    
        
    
?>




<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
</head>
<body>
    <form action="#" method="GET">
        <?php if($msg != "") echo $msg."</br></br>";?>
        Name :  <input type="text" name="name">
        email : <input type="text" name="email" >
        pass :  <input type="text" name="pass">
        <br>

        <input type="submit" value="Submit" name="submit">
    
    </form>


    
</body>
</html>