
<?php
include_once("header.php");
include_once("../../config/config.php");
?>


<body>


       <div id="page-wrapper">

       
        <div class="container-fluid">
            
            <!-- /row -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="white-box">
                        <h3 class="box-title">User Registered</h3>
                        
                        <div class="table-responsive">

                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>User ID</th>
                                        <th>Customer Name</th>
                                        <th>Customer E-mail</th>
                                        <th>Message</th>
                                        <th>Action</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>


                                <?php
        

                                    $query = "SELECT * FROM customer_query";
                                    $fire = mysqli_query($conn,$query);

                                    while ($row = mysqli_fetch_array($fire)) {
                                        
                                         $customer_id = $row['id'];
                                         $customer_name = $row['customer_name'];
                                         $customer_email = $row['email'];
                                         $message = $row['customer_message'];
                                    

                                ?>

                                    <tr>
                                        <td><?php echo $customer_id; ?></td>
                                        <td><?php echo $customer_name; ?></td>
                                        <td><?php echo $customer_email; ?></td>
                                        <td><?php echo $message; ?></td>
                                        <td><a class="btn  btn-danger btn-sm " role="button" href="customer_query_delete.php?id=<?php echo $customer_id; ?>"> Delete </a></td>
                                        
                                    </tr>

                                <?php  } ?>


                                
                                   
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>


    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="js/jquery-2.2.3.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>

    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>

</body>
</html>
